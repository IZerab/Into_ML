This is the submission of Lorenzo Beltrame for the PA5.

The submission contains 3 python files (_stochastic_optimizers, MLP, Task_2_functions) containing all the function that I used in my submission.

It also contains a Jupyter notebook file (PA5.ipynb) which is the main and the report at the same time. I decided to do like that (unlike my previous submissions) because of the large number of figures to print. 

Please check if the libraries present in both the files and the jupyter notebook are installed in your current woring directory.

To get the trained models for the autoencoders please download them from here:
https://drive.google.com/drive/folders/1I8dwiS8X6_abg8xRa8AwNOpYt18gGSMi?usp=sharing
It is my google drive, not a virus :).


Note: I set the data home for the sklearn function "fetch_lfw_people" to be inside './Dataset_2/', this lowers the run speed after you download the data and maked it easier to remove the dataframe from your pc after the correction of this assignment.